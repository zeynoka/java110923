import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double m = 9.45;
        double n = 11.5;
        System.out.println(m);


    }
}