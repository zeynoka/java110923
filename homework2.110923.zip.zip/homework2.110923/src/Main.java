import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("номер1:");
        int num1 = scanner.nextInt();
        System.out.println("номер2:");
        int num2 = scanner.nextInt();
        int mult = num1 * num2;
        int otvet = scanner.nextInt();
        if (otvet == mult){
            System.out.println(otvet);
        }
        else {
            System.out.println(mult);
        }



    }
}