import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Элвис Пресли жил с 1935 по 1977 год");
        int birthYear = scanner.nextInt();
        int deathYear = 1977;
        System.out.println((birthYear < 1935   ? "Элвис еще не родился" :""));
        System.out.println((birthYear > 1935 && birthYear <deathYear ? "Элвис жив":""));
        System.out.println((birthYear > deathYear ? "Элвис навсегда в наших сердцах!":""));
    }
}